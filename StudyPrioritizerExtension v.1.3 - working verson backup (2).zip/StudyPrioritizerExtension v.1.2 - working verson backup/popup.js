document.addEventListener('DOMContentLoaded', () => {
  const setupView = document.getElementById('setupView');
  const mainView = document.getElementById('mainView');
  const apiKeyInput = document.getElementById('apiKeyInput');
  const statusDiv = document.getElementById('recommendations');
  const openPlannerBtn = document.getElementById('openPlannerBtn');

  // -- 1. INITIALIZATION --
  chrome.storage.local.get(['geminiApiKey', 'tasks'], (result) => {
    if (result.geminiApiKey) {
      showMain();
      if (result.tasks && result.tasks.length > 0) {
        displayPreview(result.tasks);
        openPlannerBtn.style.display = 'block';
      }
    } else {
      showSetup();
    }
  });

  // -- 2. VIEW HELPERS --
  function showSetup() { setupView.classList.remove('hidden'); mainView.classList.add('hidden'); }
  function showMain() { setupView.classList.add('hidden'); mainView.classList.remove('hidden'); }

  document.getElementById('saveKeyBtn').addEventListener('click', () => {
    const key = apiKeyInput.value.trim();
    if (key) chrome.storage.local.set({ geminiApiKey: key }, () => showMain());
    else alert("Please enter a valid API Key.");
  });

  document.getElementById('changeKeyBtn').addEventListener('click', () => showSetup());
  openPlannerBtn.addEventListener('click', () => chrome.tabs.create({ url: 'planner.html' }));

  // -- 3. SCAN LOGIC --
  document.getElementById("scanBtn").addEventListener("click", async () => {
    statusDiv.innerHTML = `<p class="loading-text" style="color: #1967d2;">Connecting...</p>`;
    
    chrome.storage.local.get(['geminiApiKey', 'tasks', 'classGrades'], async (storageResult) => {
      const apiKey = storageResult.geminiApiKey;
      let masterList = storageResult.tasks || [];
      let gradebook = storageResult.classGrades || {}; 
      
      if (!apiKey) { showSetup(); return; }

      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab) { logToScreen("No active tab found.", "red"); return; }

        const isClassPage = tab.url && tab.url.includes("/core_tasks");

        chrome.tabs.sendMessage(tab.id, { action: "scan_page_with_ai" }, async (response) => {
          if (chrome.runtime.lastError || !response || !response.data) {
             logToScreen("Connection Error: Refresh ManageBac page.", "red");
             return;
          }

          logToScreen(isClassPage ? "Scanning Gradebook & Tasks..." : "Scanning Tasks...", "#1967d2");

          try {
            const modelName = await findWorkingModel(apiKey);
            const now = new Date();
            const todayStr = now.toDateString(); 
            const currentMonth = now.getMonth() + 1; // 1-12
            const currentYear = now.getFullYear();

            // AI PROMPT: Explicit Year Logic
            const systemPrompt = `
              Today is ${todayStr} (Month: ${currentMonth}, Year: ${currentYear}).
              Analyze this ManageBac page. Return JSON with "newTasks" and "completedGrades".

              RULES FOR DATES:
              1. Return dates strictly in "YYYY-MM-DD" format (e.g., "2026-01-23").
              2. YEAR LOGIC: If a task is due in January, February, or March, and the current month is December, assume the year is ${currentYear + 1}. Otherwise use ${currentYear}.
              
              RULES FOR TASKS:
              1. Exclude items marked "Completed" or "Graded".
              2. Category must be one of: "Test", "Exam", "Quiz", "Project", "Essay", "Homework".
              3. If the title mentions "Test", "Exam", or "Paper", force Category to "Test".
              
              JSON Format:
              {
                "newTasks": [{ "subject": "Math", "assignment": "Unit 3 Test", "dueDate": "2026-01-23", "priority": "HIGH", "category": "Test" }],
                "completedGrades": []
              }
            `;

            const aiData = await callGemini(apiKey, modelName, systemPrompt, response.data);

            // -- PROCESS GRADES --
            if (isClassPage && aiData.completedGrades && aiData.completedGrades.length > 0) {
              const rawSubject = aiData.completedGrades[0].subject;
              const stdSubject = standardizeSubject(rawSubject);

              if (!gradebook[stdSubject]) gradebook[stdSubject] = [];
              aiData.completedGrades.forEach(g => {
                const exists = gradebook[stdSubject].find(old => old.title === g.title);
                if (!exists) gradebook[stdSubject].push(g);
              });
              logToScreen(`Updated Grades for ${stdSubject}!`, "#188038");
            }

            // -- PROCESS TASKS --
            if (aiData.newTasks) {
              aiData.newTasks.forEach(newItem => {
                newItem.subject = standardizeSubject(newItem.subject);
                
                // Deduplicate
                const exists = masterList.find(t => t.subject === newItem.subject && t.assignment === newItem.assignment);
                if (!exists) {
                  newItem.completed = false;
                  masterList.push(newItem);
                }
              });
            }

            // Clean up completed items
            masterList.forEach(t => {
                if (gradebook[t.subject] && gradebook[t.subject].some(g => g.title === t.assignment)) {
                    t.completed = true;
                }
            });

            // SAVE
            const timeString = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            chrome.storage.local.set({ 
              tasks: masterList, 
              classGrades: gradebook, 
              lastScanTime: timeString 
            });

            openPlannerBtn.style.display = 'block';
            displayPreview(masterList);

          } catch (err) {
            logToScreen(err.message, "red");
          }
        });
      } catch (err) { logToScreen("System Error: " + err.message, "red"); }
    });
  });

  // --- HELPERS ---
  function standardizeSubject(name) {
    if (!name) return "General";
    let n = name.toLowerCase();
    n = n.replace(/\b(grade|yr|year)\s*\d+\b/g, '').trim(); 
    if (n.includes("math")) return "Mathematics";
    if (n.includes("english") || n.includes("lal") || n.includes("lang") || n.includes("lit")) return "English";
    if (n.includes("phys")) return "Physics";
    if (n.includes("chem")) return "Chemistry";
    if (n.includes("bio")) return "Biology";
    if (n.includes("hist") || n.includes("human") || n.includes("soc")) return "History";
    if (n.includes("design") || n.includes("tech")) return "Design";
    if (n.includes("span")) return "Spanish";
    if (n.includes("fren")) return "French";
    if (n.includes("tok") || n.includes("knowledge")) return "TOK";
    return name.replace(/\(.*\)/, '').replace(/[0-9]/g, '').trim(); 
  }

  async function findWorkingModel(apiKey) {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`);
    const data = await response.json();
    if (data.error) throw new Error(data.error.message);
    const validModels = data.models.filter(m => m.supportedGenerationMethods?.includes("generateContent"));
    if (!validModels.length) throw new Error("No AI models found.");
    validModels.sort((a, b) => (a.name.includes('flash') ? -1 : 1));
    return validModels[0].name;
  }

  async function callGemini(apiKey, modelName, prompt, text) {
    const url = `https://generativelanguage.googleapis.com/v1beta/${modelName}:generateContent?key=${apiKey}`;
    const fetchResponse = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contents: [{ parts: [{ text: prompt + "\nDATA:\n" + text }] }] })
    });
    const data = await fetchResponse.json();
    if (data.error) throw new Error(data.error.message);
    let aiText = data.candidates[0].content.parts[0].text.replace(/```json|```/g, '').trim();
    return JSON.parse(aiText);
  }

  function logToScreen(msg, color) {
    if (statusDiv) statusDiv.innerHTML = `<p class="loading-text" style="color:${color}">${msg}</p>`;
  }

  function displayPreview(tasks) {
    const pending = tasks.filter(t => !t.completed);
    statusDiv.innerHTML = `<p style="color:green; font-weight:bold;">${pending.length} tasks ready.</p>`;
  }
});