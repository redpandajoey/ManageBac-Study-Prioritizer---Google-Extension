document.addEventListener('DOMContentLoaded', () => {
  const taskListEl = document.getElementById('taskList');
  const classListEl = document.getElementById('classList');
  const resetBtn = document.getElementById('resetDataBtn');
  const calendarGrid = document.getElementById('calendarGrid');
  const monthNameEl = document.getElementById('monthName');
  const weightModal = document.getElementById('weightModal');
  const dayModal = document.getElementById('dayModal');
  
  let currentEditingSubject = null;
  let viewDate = new Date(); 

  loadAndRender();

  function loadAndRender() {
    chrome.storage.local.get(['tasks', 'classGrades', 'classWeights'], (result) => {
      const tasks = result.tasks || [];
      const grades = result.classGrades || {};  
      const weights = result.classWeights || {}; 
      renderClasses(tasks, grades, weights);
      renderChecklist(tasks);
      renderCalendar(tasks);
    });
  }

  // --- 1. STRICT CATEGORY LOGIC ---
  function getTaskCategoryInfo(task) {
      // We look at Title and Category separately.
      // We DO NOT look at Subject (prevents "MaTH" triggers)
      const title = (task.assignment || "").toLowerCase();
      const cat = (task.category || "").toLowerCase();
      
      // Default: Homework (Green, Priority 2)
      let info = { label: "HOMEWORK", color: "#1e8e3e", bg: "#e6f4ea", priority: 2 };

      // 1. LATE CHECK (Highest Priority: 10)
      const dueParts = task.dueDate.split('-');
      if (dueParts.length === 3) {
          const due = new Date(task.dueDate + "T00:00:00");
          const now = new Date(); now.setHours(0,0,0,0);
          if (due < now && !task.completed) {
              return { label: "⚠️ LATE", color: "#d93025", bg: "#fce8e6", priority: 10 }; 
          }
      }

      // 2. TEST DETECTOR (Priority: 5)
      // Only strict keywords.
      const isTestTitle = title.includes("test") || title.includes("exam") || title.includes("midterm") || title.includes("final") || title.includes("paper 1") || title.includes("paper 2") || title.includes("paper 3");
      const isTestCat = cat.includes("test") || cat.includes("exam");

      if (isTestTitle || isTestCat) {
          return { label: "TEST", color: "#a142f4", bg: "#f3e8fd", priority: 5 };
      } 
      
      // 3. PROJECT DETECTOR (Priority: 4)
      const isProjTitle = title.includes("project") || title.includes("ia") || title.includes("internal assessment") || title.includes("presentation") || title.includes("essay");
      const isProjCat = cat.includes("project") || cat.includes("essay");

      if (isProjTitle || isProjCat) {
          return { label: "PROJECT", color: "#e37400", bg: "#fef7e0", priority: 4 };
      } 
      
      return info;
  }

  // --- 2. RENDER CHECKLIST ---
  function renderChecklist(tasks) {
    if (!taskListEl) return;
    taskListEl.innerHTML = '';
    const todoTasks = tasks.filter(t => !t.completed);
    
    // Sort: Priority High->Low, then Date Soon->Far
    todoTasks.sort((a, b) => {
        const pA = getTaskCategoryInfo(a).priority;
        const pB = getTaskCategoryInfo(b).priority;
        if (pA !== pB) return pB - pA;
        return new Date(a.dueDate) - new Date(b.dueDate);
    });

    if (todoTasks.length === 0) {
      taskListEl.innerHTML = '<div style="text-align:center; padding:30px; color:#888;">All caught up! 🎉</div>';
      return;
    }

    todoTasks.forEach((task) => {
      const div = document.createElement('div');
      const info = getTaskCategoryInfo(task);
      
      let borderClass = info.priority >= 5 ? "high" : (info.priority === 4 ? "medium" : "low");

      div.className = `task-item ${borderClass}`;
      div.style.borderLeftColor = info.color;

      div.innerHTML = `
        <div class="checkbox-circle"></div>
        <div style="flex:1;">
           <div style="display:flex; justify-content:space-between; align-items:flex-start;">
              <strong style="font-size:13px; color:#333;">${task.subject}</strong>
              <span style="font-size:10px; font-weight:bold; color:${info.color}; background:${info.bg}; padding:2px 6px; border-radius:4px; margin-left:10px;">${info.label}</span>
           </div>
           <div style="margin:2px 0; font-size:14px;">${task.assignment}</div>
           <div style="font-size:11px; color:#777">Due: ${task.dueDate}</div>
        </div>
      `;
      div.addEventListener('click', () => {
        task.completed = true;
        chrome.storage.local.set({ tasks: tasks }, () => { loadAndRender(); });
      });
      taskListEl.appendChild(div);
    });
  }

  // --- 3. RENDER CALENDAR ---
  function renderCalendar(tasks) {
    const options = { month: 'long', year: 'numeric' };
    monthNameEl.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; width:100%;">
        <span id="prevMonth" style="cursor:pointer; padding:5px 15px; font-size:18px;">&#9664;</span>
        <span style="font-weight:bold; font-size:16px;">${viewDate.toLocaleDateString('en-US', options)}</span>
        <span id="nextMonth" style="cursor:pointer; padding:5px 15px; font-size:18px;">&#9654;</span>
      </div>
    `;

    document.getElementById('prevMonth').onclick = () => { viewDate.setMonth(viewDate.getMonth() - 1); renderCalendar(tasks); };
    document.getElementById('nextMonth').onclick = () => { viewDate.setMonth(viewDate.getMonth() + 1); renderCalendar(tasks); };

    calendarGrid.innerHTML = '';
    ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].forEach(d => {
        const el = document.createElement('div');
        el.className = 'day-name'; el.textContent = d;
        calendarGrid.appendChild(el);
    });

    const year = viewDate.getFullYear();
    const month = viewDate.getMonth();
    const firstDayIndex = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const today = new Date();

    for (let i = 0; i < firstDayIndex; i++) { calendarGrid.appendChild(document.createElement('div')); }

    // Helper: Normalize date components to YYYY-MM-DD
    const formatDateStrict = (y, m, d) => `${y}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`;

    for (let i = 1; i <= daysInMonth; i++) {
        const dayEl = document.createElement('div');
        dayEl.className = 'calendar-day';
        dayEl.textContent = i;
        
        const currentCellDate = formatDateStrict(year, month + 1, i);
        
        // Match Tasks
        const daysTasks = tasks.filter(t => {
            if (t.completed) return false;
            const parts = t.dueDate.split('-');
            if(parts.length < 3) return false;
            // Pad the stored date to match STRICT format
            const storedDate = formatDateStrict(parts[0], parts[1], parts[2]);
            return storedDate === currentCellDate;
        });

        if (daysTasks.length > 0) {
            let maxPriority = -1;
            let bestColor = "#1e8e3e"; 

            daysTasks.forEach(t => {
                const info = getTaskCategoryInfo(t);
                // Strict check: Tests (5) override Projects (4) override HW (2)
                if (info.priority > maxPriority) {
                    maxPriority = info.priority;
                    bestColor = info.color;
                }
            });

            dayEl.style.backgroundColor = bestColor;
            dayEl.style.color = "white";
            dayEl.style.fontWeight = "bold";
            dayEl.style.cursor = "pointer";
            dayEl.addEventListener('click', () => openDayOverlay(currentCellDate, daysTasks));
        }

        if (i === today.getDate() && month === today.getMonth() && year === today.getFullYear()) {
            dayEl.style.border = "2px solid #1967d2";
        }
        calendarGrid.appendChild(dayEl);
    }
  }

  // --- 4. MODALS & CLASSES ---
  function openDayOverlay(dateStr, tasks) {
    if (!dayModal) return;
    const dateObj = new Date(dateStr + "T00:00:00"); 
    document.getElementById('dayModalTitle').textContent = dateObj.toLocaleDateString('en-US', { weekday:'short', month:'short', day:'numeric' });
    
    const content = document.getElementById('dayModalContent');
    content.innerHTML = '';

    tasks.forEach(t => {
        const info = getTaskCategoryInfo(t);
        const row = document.createElement('div');
        row.style.cssText = "padding:10px; background:#f9f9f9; border-left:5px solid #ccc; margin-bottom:8px; border-radius:4px;";
        row.style.borderLeftColor = info.color;

        row.innerHTML = `
          <div style="font-weight:bold; font-size:14px; color:#333;">${t.subject}</div>
          <div style="font-size:13px;">${t.assignment}</div>
          <div style="font-size:10px; color:${info.color}; font-weight:bold; margin-top:2px;">${info.label}</div>
        `;
        content.appendChild(row);
    });
    dayModal.showModal();
  }

  function renderClasses(tasks, grades, weights) {
    if (!classListEl) return;
    classListEl.innerHTML = '';
    const subjects = new Set([...tasks.map(t => t.subject), ...Object.keys(grades)]);

    subjects.forEach(subject => {
      const subjectGrades = grades[subject] || [];
      const hasGrades = subjectGrades.length > 0;
      const finalGrade = hasGrades ? calculateWeightedGrade(subjectGrades, weights[subject]) : "--";

      const row = document.createElement('div');
      row.className = 'class-item';
      
      let gradeHtml = hasGrades 
        ? `<div style="display:flex; align-items:center; gap:8px;">
             <span style="font-size:20px; font-weight:bold; color:#1967d2;">${finalGrade}</span>
             <button class="edit-weights-btn" data-sub="${subject}" style="background:none; border:none; cursor:pointer; font-size:16px; opacity:0.6; padding:5px;">⚙️</button>
           </div>`
        : `<div style="font-size:10px; color:#e37400; font-weight:bold;">No Grades</div>`;

      row.innerHTML = `
        <div><div style="font-weight:bold; font-size:14px; color:#333;">${subject}</div></div>
        ${gradeHtml}
      `;
      classListEl.appendChild(row);
    });

    document.querySelectorAll('.edit-weights-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const targetBtn = e.target.closest('.edit-weights-btn');
        currentEditingSubject = targetBtn.dataset.sub;
        document.getElementById('modalTitle').textContent = `Weights: ${currentEditingSubject}`;
        weightModal.showModal();
        chrome.storage.local.get(['classWeights'], (r) => {
          const w = r.classWeights?.[currentEditingSubject] || { Exams:40, Assignments:40, Homework:20 };
          document.getElementById('wExams').value = w.Exams;
          document.getElementById('wAssignments').value = w.Assignments;
          document.getElementById('wHomework').value = w.Homework;
        });
      });
    });
  }

  function calculateWeightedGrade(classGrades, classWeights) {
    if (!classGrades || classGrades.length === 0) return "--";
    const w = classWeights || { Exams: 40, Assignments: 40, Homework: 20 };
    const buckets = { Exams: [], Assignments: [], Homework: [] };

    classGrades.forEach(g => {
      const name = (g.title + " " + (g.category || "")).toLowerCase();
      let bucket = 'Assignments'; 
      if (name.includes('test') || name.includes('exam') || name.includes('midterm')) bucket = 'Exams';
      else if (name.includes('homework') || name.includes('hw')) bucket = 'Homework';
      if (g.max > 0) buckets[bucket].push(g.score / g.max);
    });

    const getAvg = (arr) => arr.length ? arr.reduce((a,b)=>a+b,0) / arr.length : 0;
    let totalScore = 0; let totalWeightUsed = 0;
    if (buckets.Exams.length > 0) { totalScore += getAvg(buckets.Exams) * w.Exams; totalWeightUsed += w.Exams; }
    if (buckets.Assignments.length > 0) { totalScore += getAvg(buckets.Assignments) * w.Assignments; totalWeightUsed += w.Assignments; }
    if (buckets.Homework.length > 0) { totalScore += getAvg(buckets.Homework) * w.Homework; totalWeightUsed += w.Homework; }
    if (totalWeightUsed === 0) return "--";
    const percentage = (totalScore / totalWeightUsed) * 100;
    if (percentage >= 85) return "7"; if (percentage >= 70) return "6"; if (percentage >= 55) return "5"; if (percentage >= 40) return "4"; if (percentage >= 25) return "3"; return "2";
  }

  // --- LISTENERS ---
  document.getElementById('closeDayModal').addEventListener('click', () => dayModal.close());
  document.getElementById('closeModal').addEventListener('click', () => weightModal.close());
  if (resetBtn) resetBtn.addEventListener('click', () => { if (confirm("Reset?")) chrome.storage.local.remove(['tasks', 'classGrades'], () => location.reload()); });

  document.getElementById('saveWeights').addEventListener('click', () => {
    const newWeights = {
      Exams: parseFloat(document.getElementById('wExams').value) || 0,
      Assignments: parseFloat(document.getElementById('wAssignments').value) || 0,
      Homework: parseFloat(document.getElementById('wHomework').value) || 0
    };
    chrome.storage.local.get(['classWeights'], (r) => {
      const allWeights = r.classWeights || {};
      if (currentEditingSubject) {
        allWeights[currentEditingSubject] = newWeights;
        chrome.storage.local.set({ classWeights: allWeights }, () => {
            weightModal.close(); loadAndRender();
        });
      }
    });
  });
});