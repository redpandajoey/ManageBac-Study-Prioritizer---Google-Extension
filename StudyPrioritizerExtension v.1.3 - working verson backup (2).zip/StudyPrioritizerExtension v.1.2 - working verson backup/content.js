// content.js

// Function to clean up the page text for the AI
function getPageContent() {
  // 1. Clone the body so we don't mess up the actual page
  const clone = document.body.cloneNode(true);

  // 2. Remove scripts, styles, images, and hidden elements to save space
  const elementsToRemove = clone.querySelectorAll('script, style, noscript, svg, img, header, footer');
  elementsToRemove.forEach(el => el.remove());

  // 3. Get the clean text
  let cleanText = clone.innerText; 
  
  // 4. Clean up excessive whitespace to make the payload smaller
  cleanText = cleanText.replace(/\s+/g, ' ').trim();

  // Limit text length to prevent API errors (approx 15k characters is usually enough for grades)
  return cleanText.substring(0, 15000);
}

// Listen for the command from the popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "scan_page_with_ai") {
    console.log("ManageBac AI Scanner: Request received.");
    
    try {
      const pageData = getPageContent();
      console.log("ManageBac AI Scanner: Page text extracted (" + pageData.length + " chars).");
      sendResponse({ data: pageData });
    } catch (error) {
      console.error("ManageBac AI Scanner Error:", error);
      sendResponse({ data: null });
    }
  }
  // Return true is required to indicate we might respond asynchronously (though here we are sync)
  return true;
});